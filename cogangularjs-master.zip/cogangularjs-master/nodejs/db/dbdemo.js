/**
 * Created by Puneet on 05-Apr-16.
 */
var mysql      = require('mysql');


var connection = mysql.createConnection({
    host     : 'localhost',
    user     : 'root',
    password : 'root',
    database : 'wiprodb'
});

connection.connect();

connection.query('SELECT * FROM wiprodb.employee', function(err, rows, fields) {
    if (err) throw err;

    console.log('Rows: ', rows[0]);
});

connection.end();