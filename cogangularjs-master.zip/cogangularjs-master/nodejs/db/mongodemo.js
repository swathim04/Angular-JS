/**
 * Created by Danish Gahlout on 3/28/14.
 */

var mongo = require("mongodb");
var host = "localhost";
var port = 27017;
var db = new mongo.Db("yourdb", new mongo.Server(host, port, {safe: true}));
db.open(function (error) {
    console.log("We are connected!" + host + ":" + port);

    db.collection("user", function (error, collection) {
        console.log("We have the collection");
        console.log(error);
        collection.insert({
            _id: "1",
            name: "Puneet",
            twitter: "puneetvashisht",
            email: "tkhts@tkhts.com",
            addresses: [
                {address: "New Delhi"}, {address: "Hyderabad"}
            ]

        }, function () {
            console.log("Successfully inserted Puneet");
        });
        collection.insert({
            _id: "2",
            name: "Techknow Heights",
            twitter: "tkhts",
            email: "techknow@tkhts.com"

        }, function () {
            console.log("Successfully inserted Tkhts");
        });
    });

});
