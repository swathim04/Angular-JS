/**
 * Created by Puneet on 04-Apr-16.
 */
console.log(process.argv)

function sub(a,b){
    return a - b
}

console.log(sub(5,1))