/**
 * Created by Puneet on 04-Apr-16.
 */
var fs  = require('fs')
console.log('Starting to Read')
//var contents = fs.readFileSync('node.txt')

fs.readFile('node.txt', function(err, data){
    if(err) throw err;
    console.log('' + data)
})

asynch(foo, function (result){
    console.log('Printed in the callback' + result)
});

console.log('Ends here..')