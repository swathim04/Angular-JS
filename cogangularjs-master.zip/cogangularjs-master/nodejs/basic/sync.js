/**
 * Created by Puneet on 04-Apr-16.
 */

function foo(){
    return 'foo called'
}

/*function synch(fn){
  return fn();
 }*/

/*function whenFinished(result){
    console.log('Printed in the callback' + result)
}*/

function asynch(fn, callback){
    setTimeout(function(){
        var result = fn();
        callback(result)
    }, 500)

}

console.log('Starting');
/*var result = synch(foo)
console.log(result)*/
var result = asynch(foo, function (result){
    console.log('Printed in the callback' + result)
});
console.log(result);

console.log('Ending');