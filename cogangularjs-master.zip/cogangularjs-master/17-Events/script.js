/**
 * Created by Puneet on 29-Mar-16.
 */
(function (angular) {
    'use strict';
    function sameFunction(eventId) {
        console.log('Event: ' + eventId + '. The same event wired from two places');
    }


    angular.module('eventExample', [])
        .controller('EventController', ['$scope', function ($scope) {
            $scope.count = 0;
            console.log('Event1')
            $scope.$on('MyEvent', function (data) {
                console.log(data)
                $scope.count++;
            });
            $scope.$on('loginRequired', function() { sameFunction('auth-loginRequired');});
            $scope.$on('loginConfirmed', function () {sameFunction('auth-loginConfirmed');});
        }])

})(window.angular);
