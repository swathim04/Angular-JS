'use strict';

/**
 * @ngdoc function
 * @name angularSeedApp.controller:ArticleCtrl
 * @description
 * # ArticleCtrl
 * Controller of the angularSeedApp
 */
angular.module('angularSeedApp')
  .controller('ArticleCtrl', function () {
    this.awesomeThings = [
      'HTML5 Boilerplate',
      'AngularJS',
      'Karma'
    ];
  });
