'use strict';

/**
 * @ngdoc function
 * @name angularSeedApp.controller:MainCtrl
 * @description
 * # MainCtrl
 * Controller of the angularSeedApp
 */
angular.module('angularSeedApp')
  .controller('MainCtrl', function ($scope, localStorageService) {

    var ctrl = main;
    ctrl.a = 12;
    ctrl.sum = function(){

    }

    /*$scope.todos = [
      'HTML5 Boilerplate',
      'AngularJS',
      'Karma'
    ];*/

    var todosInStore = localStorageService.get('todos');
    $scope.todos = todosInStore && todosInStore.split('\n') || [];

    $scope.$watch('todos', function () {
      localStorageService.add('todos', $scope.todos.join('\n'));
    }, true);


    $scope.addTodo = function () {
      $scope.todos.push($scope.todo);
      $scope.todo = '';
    };

    $scope.removeTodo = function (index) {
      $scope.todos.splice(index, 1);
    };


  });
