/**
 * Created by Puneet on 05-Apr-16.
 */


var fetchAllUsers = function(db, response){
    db.open(function (error) {
        //console.log("We are connected!" + host + ":" + port);

        db.collection("user", function (error, collection) {
            console.log("We have the collection");
            console.log(error);

            collection.find({}).toArray(function(err, docs) {
                console.log("Found the following records");
                console.dir(docs);
                response.writeHead(200, {"Content-type":"application/json"});
                response.end(''  + JSON.stringify(docs))

            });

        });

    });
}

module.exports.fetchAllUsers = fetchAllUsers