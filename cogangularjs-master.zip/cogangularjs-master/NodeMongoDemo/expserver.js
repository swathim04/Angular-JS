/**
 * Created by Puneet on 06-Apr-16.
 */
var express = require('express');
var morgan  = require('morgan');
var bodyParser  = require('body-parser');
var mongoose  = require('mongoose');
var app = express();


mongoose.connect('mongodb://localhost:27017/yourdb'); // connect to database
app.use(morgan('dev')); // log every request to the conso
//app.use(express.static('public'));
app.use('/static', express.static('public'));
// use body parser so we can get info from POST and/or URL parameters
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());


// get an instance of the router for api routes
var userRoutes = express.Router();
app.use('/user', userRoutes);

require('./app/routes/user.js')(userRoutes);

app.get('/hello', function (req, res) {
    res.send('Hello World!');
});





app.post('/hello', function (req, res) {
    res.send('Hello World POST!');
})

app.get('/user/:id', function (req, res, next) {
    res.end('Welcome ' + req.params.id);
});
var port  = process.env.PORT || 8080;
app.listen(port, function () {
    console.log('Example app listening on port !' + port);
});