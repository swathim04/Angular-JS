/**
 * Created by Puneet on 06-Apr-16.
 */
var models = require('../model/user');
module.exports = function (routes) {
    routes.post('/', function (req, res) {
        console.log(req.body)

        var TempUser = req.body
        var User = new models.User({
            _id: TempUser._id,
            password: TempUser.password,
            admin : TempUser.admin

        })
        User.save(function (err) {
            if (err) throw err;
            console.log('User saved')
        })

        res.json(User)
    })

    routes.get('/', function (req, res) {

        models.User.find({}, function(err, users) {
            if(err) throw err;
            console.log(users)
            res.json(users)
        });
    })
}