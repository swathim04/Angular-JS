/**
 * Created by Puneet on 06-Apr-16.
 */
var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var UserSchema = Schema({
    _id : String,
    password: String,
    admin: Boolean
})
var User  = mongoose.model('User', UserSchema);
module.exports.User = User;