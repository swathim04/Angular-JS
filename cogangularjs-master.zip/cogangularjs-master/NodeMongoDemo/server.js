
var http = require('http');
var fs = require('fs');

var host = 'localhost'
var port = '3000'

var conf = fs.readFileSync('conf.json')
console.log('' + conf);
var con = JSON.parse(conf)
console.log('' + con.host)

var mongo = require("mongodb");
var dbcode = require("./dbcode")
var host = "localhost";
var port = 27017;
var db = new mongo.Db("yourdb", new mongo.Server(host, port, {safe: true}));

var server = http.createServer(function(request, response){
    console.log('printing request url' +  request.url)


    if(request.url.endsWith('/fetchAllUsers')){

        dbcode.fetchAllUsers(db, response);


    }

    else{
        var filePath = 'public' +request.url;
        fs.readFile(filePath, function(err, data){
            if(data){
                response.writeHead(200, {"Content-type":"text/html"});
                response.end(data)
            }
            else{
                response.writeHead(404);
                response.end('Page Not Found')
            }

        } )
    }


})

server.listen(con.port, con.host, function(){
    console.log("Listening" + con.host + ":" + con.port);
});